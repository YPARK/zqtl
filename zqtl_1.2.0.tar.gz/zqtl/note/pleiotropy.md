## Distinguishing pleiotropy vs mediation

### Generative models

Model 1:

$\mathbf{y} = X \boldsymbol{\alpha} \beta + \boldsymbol{\epsilon}_{y}$

$\mathbf{m} = X \boldsymbol{\alpha} + \boldsymbol{\epsilon}_{m}$


Model 2: Assuming $\boldsymbol{\gamma}^{\top}\boldsymbol{\alpha} \to 0$

$\mathbf{y} = X \boldsymbol{\gamma} + \boldsymbol{\epsilon}_{y}$

$\mathbf{m} = X \boldsymbol{\alpha} + \boldsymbol{\epsilon}_{m}$


### What TWAS does

First let's derive for the model 2:

$\mathbb{E}[\mathbf{m}^{\top}\mathbf{y}/n] = \boldsymbol{\alpha}^{\top} R \boldsymbol{\gamma}$ 

$\mathbb{V}[\mathbf{m}^{\top}\mathbf{y}/n] = \boldsymbol{\alpha}^{\top} R \boldsymbol{\alpha} + \boldsymbol{\gamma}^{\top} R \boldsymbol{\gamma} + \sigma_{y}^{2} \sigma_{m}^{2}$

<!-- $\mathbb{V}[\mathbf{m}^{\top}\mathbf{y}/n] = \mathbb{E}[\mathbf{m}/\sqrt{n}]^{\top}\mathbb{E}[\mathbf{m}/\sqrt{n}] + \mathbb{E}[\mathbf{y}/\sqrt{n}]^{\top}\mathbb{E}[\mathbf{y}/\sqrt{n}]$ -->

<!-- $\mathbb{V}[X \boldsymbol{\alpha} / \sqrt{n}] = X^{\top}\mathbb{V}[\boldsymbol{\alpha}] X /n$ -->

<!-- $\mathbb{V}[X \boldsymbol{\gamma} / \sqrt{n}] = X^{\top}\mathbb{V}[\boldsymbol{\gamma}] X /n$ -->

<!-- $n^{-2} \mathsf{tr}\!\left(X^{\top}\mathbb{V}[\boldsymbol{\alpha}] X X^{\top}\mathbb{V}[\boldsymbol{\gamma}] X \right)$ -->


Since the model 1 is a special case of model 2 where $\boldsymbol{\gamma} = \boldsymbol{\alpha} \beta$ and under the null we assume $\beta \to 0$:

$\mathbb{E}[\mathbf{m}^{\top}\mathbf{y}/n] = \boldsymbol{\alpha}^{\top} R \boldsymbol{\alpha} \beta$

$\mathbb{V}[\mathbf{m}^{\top}\mathbf{y}/n] = \boldsymbol{\alpha}^{\top} R \boldsymbol{\alpha} + \sigma_{y}^{2}\sigma_{m}^{2}$

### Ideal polygenic test statistic

$T = \boldsymbol{\alpha}^{\top} \boldsymbol{\gamma}$


$\mathbb{V}[T] = \mathbb{E}[\boldsymbol{\alpha}]^{\top}\mathbb{V}[\boldsymbol{\gamma}]\mathbb{E}[\boldsymbol{\alpha}] + \mathbb{E}[\boldsymbol{\gamma}]^{\top}\mathbb{V}[\boldsymbol{\alpha}]\mathbb{E}[\boldsymbol{\gamma}] + \mathsf{tr}\!\left(\mathbb{V}[\boldsymbol{\alpha}]\mathbb{V}[\boldsymbol{\gamma}]\right)$

$\mathbf{z}\sim\mathcal{N}\!\left(\sqrt{n}R\mathbf{\theta}, R\right)$

$\boldsymbol{\alpha}\sim\mathcal{N}\!\left(R^{-1}\mathbf{z}_{\alpha}/\sqrt{n}, R^{-1}/n\right)$

$R^{-1}=VD^{-2}V^{\top}$

$R^{-2}=VD^{-4}V^{\top}$

Let $W = VD^{-1}$

$\mathbb{E}[\boldsymbol{\alpha}]^{\top}\mathbb{V}[\boldsymbol{\gamma}]\mathbb{E}[\boldsymbol{\alpha}]
=(R^{-1}\mathbf{z}_{\alpha}/\sqrt{n})^{\top}R^{-1}/n (R^{-1}\mathbf{z}_{\alpha}/\sqrt{n})
=\mathbf{z}_{\alpha}^{\top} R^{-3} \mathbf{z}_{\alpha}/n^{2}$


### Model-based approach

$\boldsymbol{\gamma} \sim \mathcal{N}\!\left(\boldsymbol{\alpha} \beta, \sigma^{2} I \right)$

$\sqrt{n} R\boldsymbol{\gamma} \sim \mathcal{N}\!\left(\sqrt{n} R \boldsymbol{\alpha} \beta, \sigma^{2} n R^{2} \right)$

$\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(\mathbf{z}_{\alpha} \beta, \sigma^{2} n R^{2} \right)$

$V^{\top}\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(V^{\top}\mathbf{z}_{\alpha} \beta, \sigma^{2} n D^{4} \right)$

$n^{-1/2} D^{-1} V^{\top}\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(n^{-1/2} D^{-1} V^{\top}\mathbf{z}_{\alpha} \beta, \sigma^{2} D^{2} \right)$


which one is better? train them jointly? use factored QTL approach!

$\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(\mathbf{z}_{\alpha} \beta, \sigma^{2} n R^{2} \right)$

$R^{-1/2}\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(R^{-1/2}\mathbf{z}_{\alpha} \beta \lambda, R \right)$

$\mathbf{z}_{\gamma} \sim \mathcal{N}\!\left(\mathbf{z}_\alpha \beta, R\right)$

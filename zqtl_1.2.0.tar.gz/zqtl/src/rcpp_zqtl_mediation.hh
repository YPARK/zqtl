#ifndef RCPP_ZQTL_MEDIATION_HH_
#define RCPP_ZQTL_MEDIATION_HH_

struct effect_y_mat_t {
  explicit effect_y_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct effect_y_se_mat_t {
  explicit effect_y_se_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct effect_m_mat_t {
  explicit effect_m_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct effect_m_se_mat_t {
  explicit effect_m_se_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct conf_mat_t {
  explicit conf_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct geno_y_mat_t {
  explicit geno_y_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

struct geno_m_mat_t {
  explicit geno_m_mat_t(const Mat& _val) : val(_val) {}
  const Mat& val;
};

///////////////////////////////////////////////////////////
// estimate residual effects using MR-Egger type of idea //
//                                                       //
// eta1 = D^{-2} V' Z_qtl Theta_med'                     //
// eta2 = V' Theta_dir                                   //
// eta3 = V' Theta_conf                                  //
///////////////////////////////////////////////////////////

template <typename DIRECT, typename... DATA>
Rcpp::List _bootstrap_direct(const Mat obs_lodds, DIRECT& eta_direct,
                             const options_t& opt,
                             std::tuple<DATA...>&& data_tup);

template <typename... DATA>
Rcpp::List _bootstrap_marginal(const Mat obs_lodds, const options_t& opt,
                               std::tuple<DATA...>&& data_tup);

template <typename DIRECT, typename MEDIATED_D, typename MEDIATED_E,
          typename... DATA>
Rcpp::List _variance_calculation(DIRECT& eta_direct, MEDIATED_D& delta_med,
                                 MEDIATED_E theta_med, const options_t& opt,
                                 std::tuple<DATA...>&& data_tup);

template <typename MODEL_Y, typename DIRECT, typename CONF, typename MEDIATED_E,
          typename... DATA>
Rcpp::List _fine_map(MODEL_Y& model_y, DIRECT& eta_direct, CONF& eta_conf_y,
                     MEDIATED_E theta_med_org, const options_t& opt,
                     std::tuple<DATA...>&& data_tup);

Rcpp::List impl_fit_med_zqtl(const effect_y_mat_t& yy,        // z_y
                             const effect_y_se_mat_t& yy_se,  // z_y_se
                             const effect_m_mat_t& mm,        // z_m
                             const effect_m_se_mat_t& mm_se,  // z_m_se
                             const geno_y_mat_t& geno_y,      // genotype_y
                             const geno_m_mat_t& geno_m,      // genotype_m
                             const conf_mat_t& conf,          // snp confounder
                             const options_t& opt) {
  //////////////////////
  // check dimensions //
  //////////////////////

  if (opt.with_ld_matrix()) {
    ELOG("Deprecated: longer use full LD matrix.");
    return Rcpp::List::create();
  }

  if (yy.val.rows() != yy_se.val.rows()) {
    ELOG("Check dimensions of effect and se on y");
    return Rcpp::List::create();
  }

  if (mm.val.rows() != mm_se.val.rows()) {
    ELOG("Check dimensions of effect and se on m");
    return Rcpp::List::create();
  }

  if (mm.val.cols() != mm_se.val.cols()) {
    ELOG("Check dimensions of effect and se on m");
    return Rcpp::List::create();
  }

  if (yy.val.rows() != conf.val.rows()) {
    ELOG("Check dimensions of C");
    return Rcpp::List::create();
  }

  const Scalar n = static_cast<Scalar>(opt.sample_size());
  const Scalar n1 = static_cast<Scalar>(opt.m_sample_size());

  TLOG("GWAS sample size = " << opt.sample_size());
  TLOG("Mediator sample size = " << opt.m_sample_size());

  Mat effect_y_z, effect_sqrt_y, weight_y;
  std::tie(effect_y_z, effect_sqrt_y, weight_y) =
      preprocess_effect(yy.val, yy_se.val, n);

  Mat effect_m_z, effect_sqrt_m, weight_m;
  std::tie(effect_m_z, effect_sqrt_m, weight_m) =
      preprocess_effect(mm.val, mm_se.val, n1);

  /////////////////////////////////
  // Pre-process genotype matrix //
  /////////////////////////////////

  Mat U, D, Vt;
  std::tie(U, D, Vt) = do_svd(geno_y.val, opt);
  Mat D2 = D.cwiseProduct(D);

  Mat U_m, D_m, Vt_m;
  std::tie(U_m, D_m, Vt_m) = do_svd(geno_m.val, opt);
  Mat D2_m = D_m.cwiseProduct(D_m);

  TLOG("Finished SVD of genotype matrix");

  // alpha.uni           = S1 R1 inv(S1) alpha
  //
  // alpha               = S1 inv(R1) inv(S1) alpha.uni
  //                     = S1 V1 inv(D1^2) t(V1) inv(S1) alpha.uni
  //
  // t(V) R inv(S) alpha = t(V) V D^2 t(V) inv(S) alpha
  //                     = D^2 t(V) (S1/S) V1 inv(D1^2) t(V1) inv(S1)
  //                     alpha.uni
  //                   M = D^2 t(V) inv(S) S1 (V1/D1) t(V1/D1) * Z_alpha

  Mat Vt_m_d = D_m.cwiseInverse().asDiagonal() * Vt_m;

  // un-normalized version is more stable
  effect_m_z = Vt.transpose() * D2.asDiagonal() * Vt * Vt_m_d.transpose() *
               Vt_m_d * effect_m_z;

  // Mat M(Vt.rows(), effect_m_z.cols());
  // Mat VtZ = Vt_m_d * effect_m_z;
  // Mat invS_S1 = weight_y.asDiagonal() * effect_sqrt_m;  // p x K
  // Mat stuff(Vt.rows(), 1);
  // for (Index k = 0; k < effect_m_z.cols(); ++k) {
  //   stuff = Vt_m_d.transpose() * VtZ.col(k);
  //   M.col(k) = D2.asDiagonal() * Vt * stuff.cwiseProduct(invS_S1.col(k));
  // }

  Mat Y = Vt * effect_y_z;
  Mat M = Vt * effect_m_z;

  zqtl_model_t<Mat> model_y(Y, D2);

  ////////////////////////////////////////////////////////////////
  // construct delta_med to capture overall (potential) mediation effect
  auto theta_med = make_dense_spike_slab<Scalar>(M.cols(), Y.cols(), opt);
  auto delta_med = make_regression_eta(M, Y, theta_med);

  Mat m_bias = M * Mat::Ones(M.cols(), 1) / static_cast<Scalar>(M.cols());
  auto theta_med_bias =
      make_dense_slab<Scalar>(static_cast<Index>(1), Y.cols(), opt);
  auto delta_med_bias = make_regression_eta(m_bias, Y, theta_med_bias);

  // intercept    ~ R 1 theta
  // Vt intercept ~ D2 Vt 1 theta
  Mat VtI = Vt * Mat::Ones(Vt.cols(), static_cast<Index>(1)) /
            static_cast<Scalar>(Vt.cols());
  auto theta_direct = make_dense_slab<Scalar>(VtI.cols(), Y.cols(), opt);
  auto eta_direct = make_regression_eta(VtI, Y, theta_direct);

  if (opt.weight_y()) eta_direct.set_weight(weight_y);

  // confounder -- or bias
  Mat VtC = Vt * conf.val;
  auto theta_conf_y = make_dense_slab<Scalar>(VtC.cols(), Y.cols(), opt);
  auto eta_conf_y = make_regression_eta(VtC, Y, theta_conf_y);

#ifdef EIGEN_USE_MKL_ALL
  // random seed initialization
  VSLStreamStatePtr rng;
  vslNewStream(&rng, VSL_BRNG_SFMT19937, opt.rseed());
  omp_set_num_threads(opt.nthread());
#else
  std::mt19937 rng(opt.rseed());
#endif

  ////////////////////////////////////////////////////////////////
  // Match scales -- just to help inference

  if (opt.do_rescale()) {
    rescale(Y);
    rescale(M);
    rescale(VtI);
    rescale(Vt);
    rescale(VtC);
  }

  ////////////////////////////////////////////////////////////////
  // Estimate observed full model

  auto llik1 = impl_fit_eta_delta(model_y, opt, rng,
                                  std::make_tuple(eta_direct, eta_conf_y),
                                  std::make_tuple(delta_med));

#ifdef EIGEN_USE_MKL_ALL
  vslDeleteStream(&rng);
#endif

  // Fine-mapping QTLs
  Rcpp::List finemap = Rcpp::List::create();
  if (opt.med_finemap()) {
    finemap =
        _fine_map(model_y, eta_direct, eta_conf_y, theta_med, opt,
                  std::make_tuple(Y, M, U, D2, Vt, VtC, weight_y, weight_m));
  }

  TLOG("Finished joint model estimation\n\n");

  Rcpp::List boot = Rcpp::List::create();

  if (opt.nboot() > 0) {
    if (opt.do_hyper())
      WLOG("bootstrap with do_hyper() can yield invalid null");

    if (opt.bootstrap_method() == 1) {
      boot = _bootstrap_direct(log_odds_param(theta_med), eta_direct, opt,
                               std::make_tuple(Y, M, D2, weight_y, Vt));
    } else if (opt.bootstrap_method() == 2) {
      boot = _bootstrap_marginal(log_odds_param(theta_med), opt,
                                 std::make_tuple(Y, M, D2, weight_y, U, Vt));
    }
  }

  Rcpp::List var_decomp = _variance_calculation(
      eta_direct, delta_med, theta_med, opt, std::make_tuple(Y, M, U, D2, Vt));

  TLOG("Finished variance decomposition\n\n");

  return Rcpp::List::create(
      Rcpp::_["Y"] = Y, Rcpp::_["U"] = U, Rcpp::_["M"] = M, Rcpp::_["Vt"] = Vt,
      Rcpp::_["S.inv.y"] = weight_y, Rcpp::_["S.inv.m"] = weight_m,
      Rcpp::_["D2"] = D2,
      Rcpp::_["param.mediated"] = param_rcpp_list(theta_med),
      Rcpp::_["param.direct"] = param_rcpp_list(theta_direct),
      Rcpp::_["param.covariate.eta"] = param_rcpp_list(theta_conf_y),
      Rcpp::_["llik"] = llik1, Rcpp::_["bootstrap"] = boot,
      Rcpp::_["finemap"] = finemap, Rcpp::_["var.decomp"] = var_decomp);
}

////////////////////////
// finemapping method //
////////////////////////

template <typename MODEL_Y, typename DIRECT, typename CONF, typename MEDIATED_E,
          typename... DATA>
Rcpp::List _fine_map(MODEL_Y& model_y, DIRECT& eta_direct, CONF& eta_conf_y,
                     MEDIATED_E theta_med_org, const options_t& opt,
                     std::tuple<DATA...>&& data_tup) {
  Mat Y, M, U, D2, Vt, VtC, weight_y, weight_m;
  std::tie(Y, M, U, D2, Vt, VtC, weight_y, weight_m) = data_tup;

  // Construct M including potential mediators
  Mat row_max_lodds = log_odds_param(theta_med_org).rowwise().maxCoeff();
  std::vector<Index> med_include(0);

  for (Index j = 0; j < row_max_lodds.size(); ++j) {
    if (row_max_lodds(j) > opt.med_lodds_cutoff()) med_include.push_back(j);
  }

  const Index n_med_include = med_include.size();
  Rcpp::List finemap = Rcpp::List::create();

  if (n_med_include > 0) {
    TLOG("Fine-mapping QTLs on " << n_med_include << " mediators");

    Mat Msub(Vt.rows(), n_med_include);
    Mat weight_m_sub(Vt.cols(), n_med_include);
    Index c = 0;
    for (Index j : med_include) {
      Msub.col(c) = M.col(j);
      weight_m_sub.col(c) = weight_m.col(j);
      c++;
    }

    zqtl_model_t<Mat> model_m(Msub, D2);

    auto theta_left =
        make_dense_spike_slab<Scalar>(Vt.cols(), Msub.cols(), opt);
    auto theta_right =
        make_dense_spike_slab<Scalar>(Y.cols(), Msub.cols(), opt);
    auto eta_med = make_mediation_eta(Vt, Msub, Vt, Y, theta_left, theta_right);
    if (opt.weight_m()) eta_med.set_weight_pk(weight_m_sub);
    if (opt.weight_y()) eta_med.set_weight_pt(weight_y);

    auto theta_conf_m = make_dense_slab<Scalar>(VtC.cols(), Msub.cols(), opt);
    auto eta_conf_m = make_regression_eta(VtC, Msub, theta_conf_m);

    dummy_eta_t dummy;

    eta_direct.resolve();

#ifdef EIGEN_USE_MKL_ALL
    // random seed initialization
    VSLStreamStatePtr rng;
    vslNewStream(&rng, VSL_BRNG_SFMT19937, opt.rseed());
    omp_set_num_threads(opt.nthread());
#else
    std::mt19937 rng(opt.rseed());
#endif

    auto llik2 =
        impl_fit_mediation(model_y, model_m, opt, rng,
                           std::make_tuple(eta_med),     // mediation
                           std::make_tuple(eta_conf_y),  // eta[y] only
                           std::make_tuple(eta_conf_m),  // eta[m] only
                           std::make_tuple(dummy),       // delta[y]
                           std::make_tuple(dummy),       // delta[m]
                           std::make_tuple(eta_direct),  // clamped eta[y]
                           std::make_tuple(dummy));      // clamped eta[m]

#ifdef EIGEN_USE_MKL_ALL
    vslDeleteStream(&rng);
#endif

    std::for_each(med_include.begin(), med_include.end(),
                  [](Index& x) { ++x; });

    finemap = Rcpp::List::create(
        Rcpp::_["llik"] = llik2, Rcpp::_["mediators"] = med_include,
        Rcpp::_["param.qtl"] = param_rcpp_list(theta_left),
        Rcpp::_["param.mediated"] = param_rcpp_list(theta_right));
  }

  return finemap;
}

////////////////////////
// bootstrap method I //
////////////////////////

template <typename DIRECT, typename... DATA>
Rcpp::List _bootstrap_direct(const Mat obs_lodds, DIRECT& eta_direct,
                             const options_t& opt,
                             std::tuple<DATA...>&& data_tup) {
  Mat Y, M, D2, weight_y, Vt;
  std::tie(Y, M, D2, weight_y, Vt) = data_tup;

  // bootstrap parameters
  auto theta_boot_med = make_dense_spike_slab<Scalar>(M.cols(), Y.cols(), opt);
  auto delta_boot_med = make_regression_eta(M, Y, theta_boot_med);

  auto theta_boot_direct =
      make_dense_spike_slab<Scalar>(Vt.cols(), Y.cols(), opt);
  auto eta_boot_direct = make_regression_eta(Vt, Y, theta_boot_direct);
  if (opt.weight_y()) eta_boot_direct.set_weight(weight_y);

  Mat FD = Mat::Ones(M.cols(), Y.cols());
  Mat PVAL(M.cols(), Y.cols());

  const Scalar zero_val = 0.0;
  const Scalar one_val = 1.0;

  auto add_false_discovery = [&](const Scalar& obs, const Scalar& perm) {
    if (obs <= perm) return one_val;
    return zero_val;
  };

#ifdef EIGEN_USE_MKL_ALL
  VSLStreamStatePtr rng;
  vslNewStream(&rng, VSL_BRNG_SFMT19937, opt.rseed());
  omp_set_num_threads(opt.nthread());
#else
  std::mt19937 rng(opt.rseed());
#endif

  Index nboot;
  Index nmed = theta_boot_med.rows();
  Index nout = theta_boot_med.cols();
  running_stat_t<Mat> LODDS(nmed, nout);
  zqtl_model_t<Mat> boot_model(Y, D2);
  Mat lodds_boot_mat = Mat::Zero(nmed, opt.nboot() * nout);

  for (nboot = 0; nboot < opt.nboot(); ++nboot) {
    const Scalar denom = static_cast<Scalar>(nboot + 2.0);

    eta_direct.resolve();
    boot_model.sample(eta_direct.sample(rng));

    initialize_param(theta_boot_direct);
    initialize_param(theta_boot_med);

    impl_fit_eta_delta(boot_model, opt, rng, std::make_tuple(eta_boot_direct),
                       std::make_tuple(delta_boot_med));

    Mat log_odds = log_odds_param(theta_boot_med);
    FD += obs_lodds.binaryExpr(log_odds, add_false_discovery);

    // start = 1 + nboot * nout, end = (nboot + 1) * nout
    for (Index j = 0; j < nout; ++j)
      lodds_boot_mat.col(j + nboot * nout) = log_odds.col(j);

    PVAL = FD / denom;
    LODDS(log_odds_param(theta_boot_med));

    TLOG("Bootstrap : " << (nboot + 1) << " / " << opt.nboot()
                        << " min p-value " << PVAL.minCoeff() << " max p-value "
                        << PVAL.maxCoeff());

    initialize_param(theta_boot_direct);
    initialize_param(theta_boot_med);
  }
  TLOG("Finished bootstrapping by direct model\n\n");

#ifdef EIGEN_USE_MKL_ALL
  vslDeleteStream(&rng);
#endif

  return Rcpp::List::create(
      Rcpp::_["stat.mat"] = lodds_boot_mat, Rcpp::_["nboot"] = nboot + 1,
      Rcpp::_["pval"] = PVAL, Rcpp::_["fd"] = FD,
      Rcpp::_["lodds.mean"] = LODDS.mean(), Rcpp::_["lodds.var"] = LODDS.var());
}

/////////////////////////
// bootstrap method II //
/////////////////////////

template <typename... DATA>
Rcpp::List _bootstrap_marginal(const Mat obs_lodds, const options_t& opt,
                               std::tuple<DATA...>&& data_tup) {
  Mat Y, M, D2, weight_y, U, Vt;
  std::tie(Y, M, D2, weight_y, U, Vt) = data_tup;

  ////////////////////////////////////////////////////////////////
  // Estimate the marginal model
  zqtl_model_t<Mat> model_marg(Y, D2);

  // this must be without spike-slab; otherwise it will become zero
  auto theta_marg = make_dense_col_slab<Scalar>(Vt.cols(), Y.cols(), opt);
  auto eta_marg = make_regression_eta(Vt, Y, theta_marg);
  if (opt.weight_y()) eta_marg.set_weight(weight_y);

  // bootstrap parameters
  auto theta_boot_med = make_dense_spike_slab<Scalar>(M.cols(), Y.cols(), opt);
  auto delta_boot_med = make_regression_eta(M, Y, theta_boot_med);

  auto theta_boot_direct =
      make_dense_spike_slab<Scalar>(Vt.cols(), Y.cols(), opt);
  auto eta_boot_direct = make_regression_eta(Vt, Y, theta_boot_direct);

  if (opt.weight_y()) eta_boot_direct.set_weight(weight_y);

  Mat FD = Mat::Ones(M.cols(), Y.cols());
  Mat PVAL(M.cols(), Y.cols());

  const Scalar zero_val = 0.0;
  const Scalar one_val = 1.0;

  auto add_false_discovery = [&](const Scalar& obs, const Scalar& perm) {
    if (obs <= perm) return one_val;
    return zero_val;
  };

#ifdef EIGEN_USE_MKL_ALL
  VSLStreamStatePtr rng;
  vslNewStream(&rng, VSL_BRNG_SFMT19937, opt.rseed());
  omp_set_num_threads(opt.nthread());
#else
  std::mt19937 rng(opt.rseed());
#endif

  auto llik = impl_fit_eta(model_marg, opt, rng, std::make_tuple(eta_marg));

  TLOG("Finished estimation of the marginal model\n\n");

  Index nboot;
  Index nmed = theta_boot_med.rows();
  Index nout = theta_boot_med.cols();
  running_stat_t<Mat> LODDS(nmed, nout);
  zqtl_model_t<Mat> boot_model(Y, D2);
  Mat lodds_boot_mat = Mat::Zero(nmed, opt.nboot() * nout);

  for (nboot = 0; nboot < opt.nboot(); ++nboot) {
    const Scalar denom = static_cast<Scalar>(nboot + 2.0);
    eta_marg.resolve();
    boot_model.sample(eta_marg.sample(rng));

    initialize_param(theta_boot_direct);
    initialize_param(theta_boot_med);

    impl_fit_eta_delta(boot_model, opt, rng, std::make_tuple(eta_boot_direct),
                       std::make_tuple(delta_boot_med));

    Mat log_odds = log_odds_param(theta_boot_med);
    FD += obs_lodds.binaryExpr(log_odds, add_false_discovery);

    // start = 1 + nboot * nout, end = (nboot + 1) * nout
    for (Index j = 0; j < nout; ++j)
      lodds_boot_mat.col(j + nboot * nout) = log_odds.col(j);

    PVAL = FD / denom;
    LODDS(log_odds_param(theta_boot_med));

    TLOG("bootstrap : " << (nboot + 1) << " / " << opt.nboot()
                        << " min p-value " << PVAL.minCoeff() << " max p-value "
                        << PVAL.maxCoeff());

    initialize_param(theta_boot_direct);
    initialize_param(theta_boot_med);
  }

  TLOG("Finished bootstrapping by marginal model\n\n");

#ifdef EIGEN_USE_MKL_ALL
  vslDeleteStream(&rng);
#endif

  return Rcpp::List::create(
      Rcpp::_["stat.mat"] = lodds_boot_mat,
      Rcpp::_["marginal"] = param_rcpp_list(theta_marg),
      Rcpp::_["nboot"] = nboot + 1, Rcpp::_["pval"] = PVAL, Rcpp::_["fd"] = FD,
      Rcpp::_["lodds.mean"] = LODDS.mean(), Rcpp::_["lodds.var"] = LODDS.var(),
      Rcpp::_["llik.marg"] = llik);
}

template <typename DIRECT, typename MEDIATED_D, typename MEDIATED_E,
          typename... DATA>
Rcpp::List _variance_calculation(DIRECT& eta_direct, MEDIATED_D& delta_med,
                                 MEDIATED_E theta_med, const options_t& opt,
                                 std::tuple<DATA...>&& data_tup) {
  Mat Y, M, U, D2, Vt;
  std::tie(Y, M, U, D2, Vt) = data_tup;

  const Index _n = U.rows();
  const Index _T = Y.cols();
  const Scalar n = static_cast<Scalar>(U.rows());
  const Index nboot = 500;
  const Index _K = M.cols();

#ifdef EIGEN_USE_MKL_ALL
  VSLStreamStatePtr rng;
  vslNewStream(&rng, VSL_BRNG_SFMT19937, opt.rseed());
  omp_set_num_threads(opt.nthread());
#else
  std::mt19937 rng(opt.rseed());
#endif

  // direct   : X * theta_direct
  //            sqrt(n) U D Vt * theta_direct
  //            sqrt(n) U D eta_direct
  //
  // mediated : X * inv(R) * mm.val * theta_med
  //            X * V inv(D2) Vt * mm.val * theta_med
  //            sqrt(n) U inv(D) * Vt * mm.val * theta_med
  //            sqrt(n) U inv(D) * delta_med
  //
  Mat snUD = std::sqrt(n) * U * D2.cwiseSqrt().asDiagonal();
  Mat snUinvD = std::sqrt(n) * U * D2.cwiseSqrt().cwiseInverse().asDiagonal();
  Mat UinvD = U * D2.cwiseSqrt().cwiseInverse().asDiagonal();

  eta_direct.resolve();
  delta_med.resolve();

  Mat direct_ind(_n, _T);
  Mat med_ind(_n, _T);

  Mat temp(1, _T);
  running_stat_t<Mat> direct_stat(1, _T);
  running_stat_t<Mat> med_stat(1, _T);

  for (Index b = 0; b < nboot; ++b) {
    direct_ind = snUD * eta_direct.sample(rng);
    column_var(direct_ind, temp);
    direct_stat(temp / n);

    med_ind = snUinvD * delta_med.sample(rng);
    column_var(med_ind, temp);
    med_stat(temp / n);
  }

#ifdef EIGEN_USE_MKL_ALL
  vslDeleteStream(&rng);
#endif

  Mat theta_med_mean = mean_param(theta_med);
  Mat var_med_each(_K, _T);

  for (Index k = 0; k < _K; ++k) {
    column_var(snUinvD * (M.col(k) * theta_med_mean.row(k)), temp);
    var_med_each.row(k) = temp / n;
  }

  return Rcpp::List::create(Rcpp::_["var.direct.mean"] = direct_stat.mean(),
                            Rcpp::_["var.direct.var"] = direct_stat.var(),
                            Rcpp::_["var.med.each"] = var_med_each,
                            Rcpp::_["var.med.mean"] = med_stat.mean(),
                            Rcpp::_["var.med.var"] = med_stat.var());
}

#endif

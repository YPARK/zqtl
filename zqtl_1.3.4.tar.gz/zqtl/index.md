# Summary-based QTL mapping

## Notes on Mac OS X users

For some unknown reason, compiled Eigen library does not work as
expected with `clang` compiler, e.g., producing lots of `nan` results.
We recommend using `gcc` after version 5 that fully support
`std=c++14` flag.

## Installation (a simple version)

Just do this in `R`
```
> install.packages('zqtl_x.x.x.tar.gz')
```

## Installation (optional)

Prerequisite: `Rcpp`, `RcppEigen`, `RcppProgress` packages

Make sure your R development environment support `C++14` by including
`-std=c++14` to `CFLAGS` and `CXXFLAGS` in `~/.R/Makevars` file.
For instance,
```
CXX = g++-6
CXXFLAGS = -O3 -std=c++14
CFLAGS = -O3 -std=c++14
```

Build package locally.
```
$ R CMD build .
```

You will have `zqtl_x.x.x.tar.gz` gzipped file in current directory
(`x.x.x` can be any version of the package).  Install package within
R:

```
> install.packages('zqtl_x.x.x.tar.gz')
```

To speed up matrix-vector multiplication, one can compile codes with
Intel MKL library.  Currently `RcppEigen` does not support `BLAS` only
options (this may not be true).

Enjoy!

# Release notes

### v.1.3.4

- Remove "backfire control" and "two step optimization"
- Revive variance calculation with residual estimation
- Make a room for univariate confounding factors
- Output "clean" version of GWAS effects

### v.1.3.3

- Minor fix on smoothness of the unmediated effect
- Add `do.control.backfire` to regress out `M0 -> M`.
- Add experimental factorization model `factorization.model = 1`

### v.1.3.2

- Estimate unmediated factors by factorization
- Boost sample size by resampling eigen vectors
- Allow two step optimization
- Parametric bootstrap for sensitivity analysis

### v.1.3.1

- Make propensity sampling as second option
- Estimate the unmediated effect as before
- Drop weight features (not so useful)
- Allow multiple mediators in the conditional analysis

### v.1.3.0

- Counterfactual estimation of average unmediated effects via sampling
- Factored mediation model

### v.1.2.3

- Take multivariate effect sizes for mediator QTLs
- Initialization by dot product

### v.1.2.2

- Restrict number of mediator variables during the estimation of unmediated effects

### v.1.2.1

- Estimation of average unmediated effects
- Minor bugfix in regression (twice rescaling)

### v.1.2.0

- Matrix factorization for confounder correction
- Confirmed usefulness of non-negative parameters
- Simplified pleiotropy model in mediation analysis
- Adjust scales by standard deviation
- Variance model in mediation analysis

### v.1.1.0

- Spiked Gamma for the factored zQTL methods
- Additional covariate component for confounder correction

### v.1.0.1

- Variance calculation. See `note/variance.md` for details.
- Random effect component to account for uncertainty of individuals
- Removing LD-structure bias between mediation QTL and GWAS cohorts

### v.1.0.0

- Initial version migrated from MIT github

# Bug reports

Yongjin Park `ypp@csail.mit.edu`

# Technical details

## Standardization of summary statistics

As we can read from Finucane _et al._ summary-based methods are quite
sensitive to the prevalence of SNPs with unusually strong associations
as they do not follow theoretical null distributions.

> __Outlier removal.__ To minimize standard error, we remove outlier
> SNPs by excluding SNPs with χ2 > max{80, 0.001N}, where N is the
> maximum sample size in the study. We also remove the MHC region from
> all analyses, because of its unusual LD patterns and genetic
> architecture.

For a univariate mediation analysis, the scale and meanshift of
summary statistics do not substantially affect downstream analysis.
However, for our model based analysis, we need z-scores of GWAS and
mediation QTLs should behave similarly, just as a design matrix in
Lasso regression is standardized.

Let's consider a generative scheme with a single bias term $\mu$ and
scaling by $\tau$:

$$\mathbf{z} \sim \mathcal{N}\!\left(R (\mu I), \tau R\right)$$

where the SNP-SNP covariance matrix $R = V^{\top} D^{2} V$ was
calculated from singular value decomposition of genotype matrix
$X/\sqrt{n} = UDV^{\top}$.  An equivalent isotropic model could be
derived after multiplying by $D^{-1}V^{\top}$:

$$D^{-1} V^{\top}\mathbf{z} \sim \mathcal{N}\!\left(D V^{\top} I \mu, \tau I\right)$$

Letting $\mathbf{y}\equiv D^{-1} V^{\top}\mathbf{z}$ and $\mathbf{x} \equiv D V^{\top} I$,
we can find the maximum likelihood estimate $\hat{\mu}$ by minimizing

$$- \frac{1}{2} \ln \tau -\frac{1}{2\tau} \sum_{k} \left(y_{k} - x_{k} \mu\right)^{2},$$

which leads to 

$$\hat{\mu} = \frac{\sum_{k} y_{k} x_{k}}{\sum_{k} x_{k}^{2}} = \frac{\mathbf{x}^{\top}\mathbf{y}}{\mathbf{x}^{\top}\mathbf{x}} = \frac{\mathbf{z}^{\top}I}{I^{\top}RI}$$

and

$$\hat{\tau} = \frac{1}{K - 1}\|\mathbf{y} - \hat{\mu}\mathbf{x}\|^{2}$$

Using these, we standardize

$$\mathbf{z} \gets (\mathbf{z} - \hat{\mu} RI)/\sqrt{\hat{\tau}}$$


## Simulation

Let's take a look at Kichaev _et al._ (2014)

> Once we established the causal SNPs, we used a linear model to
> simulate continuous phenotypes such that the causal SNPs aggregated
> to explain a fixed proportion of the phenotypic variance
> ($h_{g}^{2}$). This phenotypic variance was partitioned equally
> amongst all the causal SNPs (qualitatively similar results were
> obtained when phenotypic variance was unevenly partitioned among
> causal variants (see Figure S6)). In particular, the individual's
> phenotype was drawn according to $Y_{m} =
> \sum_{i=1}^{N_{c}}\beta_{i} G_{im} + \epsilon_{m}$, where $N_{c}$ is
> the total number of causal variants, $\beta_{i}$ is the effect size
> of the ith causal SNP, $G_{im}$ is number of copies of the risk
> allele $i$ (randomly assigned as reference or alternate) for
> individual m, and $\epsilon_{m} \sim \mathcal{N}\!\left(0, 1 -
> h_{g}^{2}\right)$. Finally, we calculated association Z-scores
> ($Z_{ij}$) at each SNP $i,j$ by taking the Wald statistic from the
> regression of the Y on $G_{ij}$, where Y is a vector of phenotypes
> for M individuals and $G_{ij}$ is the vector of corresponding
> genotypes for the ith SNP at the jth locus. For simulations that
> required loci greater than 10 KB, we instead drew Z-scores from a
> Multivariate Normal distribution with covariance equal to LD based
> on the European 1 KG and non-centrality parameters at causal sites
> drawn from a Normal distribution with mean 5 and standard deviation
> 0.2.

From Kichaev _et al._ (2017)

> We simulated phenotypes under a linear model such that for
> individual i of population p, their phenotype Y was drawn as $Y_{ip}
> = \sum_{j=1}^{N_{c}} \beta_{j} G_{ijp} + \epsilon_{ip}$, where
> $N_{c}$ is the total number of causal variants, $\beta_{j}$ is the
> effect size of the jth causal SNP, $G_{ijp}$ is the number of copies
> of the risk allele j for individual i of population p. Following
> recent works, we simulated similar heritability across populations
> The population-specific error term, $\epsilon_{ip}$, was drawn
> according to a $\mathcal{N}\!\left(0,\sigma_{ep}^{2}\right)$, where
> $\sigma_{ep}^{2} = (\sigma_{gp}^{2} - h_{g}^{2}
> \sigma_{gp}^{2})/h_{g}^{2}$, $\sigma_{gp}^{2} =
> \boldsymbol{\beta}^{\top}\mathsf{Cov}(X_{p})\boldsymbol{\beta}$, and
> $\mathsf{Cov}(X_{p})$ is the population-specific covariance of the
> genotypes (LD). The effect size, $\beta_{j}$, was set to be
> inversely proportional to the average SD of the population allele
> frequencies; this is roughly equivalent to assuming that each causal
> SNP explains an equal proportion of the phenotypic variance.


## Correction of non-genetic correlations between z-scores

Suppose we have a phenotype vector generated by two components,
genotype matrix `G` and unwanted confounder matrix `U`:

```
y = G θ + U δ + G0 α
```

Let's take the advantages of this fact `G0 t(G) -> 0`.  Now consider
two z-scores of the same number of SNPs:

```
z ~ t(G) y = t(G)G θ + t(G) U δ + t(G) G0 α
           -> R θ + t(G) U δ
```
and

```
z0 ~ t(G0) y = t(G0)G θ + t(G) U δ + t(G0) G0 α
           -> λ I θ + t(G0) U δ + R0 α
```

Therefore correlation between `z` and `z0` will approach to `δ^2||u||` up
to some constant factor.


## Removing discrepancy between two reference panels in mediation analysis

Assume `X1 / sqrt(n1) = U1 D1 t(V1)` and `X / sqrt(n) = U D t(V)`.

```
E[α.hat]           = S1 R1 inv(S1) α
```
therefore
```
E[α]               = S1 inv(R1) inv(S1) α.hat
                   = S1 V1 inv(D1^2) t(V1) inv(S1) α.hat
```
Construct a "design matrix" for the mediation effect:
```
t(V) R inv(S) E[α] = t(V) V D^2 t(V) inv(S) α
                   = D^2 t(V) inv(S) S1 V1 inv(D1^2) t(V1) inv(S1) α.hat
M                  = D^2 t(V) inv(S) S1 (V1/D1) t(inv(D1)V1) * Zα
```
Mediation regression model assuming mean-field distribution of `β`:
```
E[Δ] = M E[β]
V[Δ] = M^2 V[β]
```
For a perfect mediation:
```
E[t(V)Zθ] = E[Δ]
```

## Variance calculation

### Notations

- p : the number of SNPs

- n : the number of individuals

- n0 : the number of individuals in the mediation QTL models

- K : the number of mediators

- X : a standardized genotype matrix (n x p); mean = 0 and variance 1

- y : phenotype vector (n x 1)

- z : z-score vector of XWAS (p x 1)

- a : the estimated univariate effect size of mediation QTLs (p x K)

- S0 : the diagonal matrix of standard errors (p x p)

- za : the z-score matrix for mediation QTLs

- α : multivariate effect size of mediation QTLs

- β : mediation effect size (K x 1)

- γ : unmediated effect size (p x 1)


### Estimation of residual effects on reference panel

From the linear model `y = X θ + ε`, we can derive the estimated
univariate statistics.

```
θ.uni = t(X)y / n
      = t(X)(X θ + ε) / n
      = t(X)X θ / n + t(X)ε / n
```

With `S = σ / sqrt(n)` and exploiting SVD `X/sqrt(n) = UD t(V)`,

```
z     = θ.uni * sqrt(n) / σ
      = R (θ * sqrt(n)/σ) + t(X/sqrt(n)) ε /σ 

t(V)z = t(V) V D^2 t(V) (θ * sqrt(n)/σ) + t(V)VD t(U) (ε/σ)
      = D^2 t(V) (θ * sqrt(n)/σ) + D^2 inv(D)t(U) (ε/σ)
```
Treating `y.tilde = t(V)z` and `Δ = inv(D)t(U)`,
we can estimate the individual-level residual values `ε` fitting the regression :

```
y.tilde ~ ... + D^2 Δ (ε/σ) + N(0, D^2)
```

Then we can estimate the scaled residual variance by `V[ε/σ]`, and we
can approximate that value with `sum(ε^2)/nσ^2` if `E[ε_i] = 0`.  For
unbiased reference panel, it is not so hard to see that `V[ε/σ] -> 1`.

## Variance components

We define variance explained by the linear model on the reference cohort genotype matrix, 
`var_model = V[Xθ]/σ^2`. Defining `η = Xθ` we can estimate

```
V[Xθ] = Σ η_j^2/n - (Σ η_j/n)^2.
```

Alternatively we could use `t(θ) R θ`, but we may not have `Ε[Xθ] = 0` in practice.
Variance unexplained:

```
var_residual = V[ε/σ] ~ Σ ε_i^2 / nσ^2
```

### Reconciling different samples sizes between the mediation and GWAS models

The model for mediated QTLs:

```
E[a]  = S0 R inv(S0)α
α     = S0 inv(R) inv(S0) E[a]
```

For simplicity we assume `S = (σ/sqrt(n))I` and `S0 = (σ0/sqrt(n0))I` and `X` is standardized.

```
E[θ.uni] = S R inv(S) θ
         = S R inv(S) (αβ + γ)
         = S R inv(S) S0 inv(R) inv(S0) E[a] β + S R inv(S) γ
         = E[a] β + S R inv(S) γ
E[z]     = inv(S) E[a] β + R inv(S) γ
t(V)E[z] = (t(V) inv(S) E[a]) β + D^2 t(V) inv(S) γ
         = (t(V) Λ inv(S0) E[a]) β + D^2 t(V) inv(S) γ
where
Λ        = sqrt(n)/sqrt(n0) I
```

- Variance explained by mediated component:

```
αβ            = inv(R) E[a] β = V inv(D^2) t(V) E[a] β
var_mediation = Σ (αβ)_j^2 / σ^2
```

